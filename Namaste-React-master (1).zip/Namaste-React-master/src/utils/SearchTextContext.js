import { createContext } from "react";

const SearchTextContext = createContext();

export default SearchTextContext;