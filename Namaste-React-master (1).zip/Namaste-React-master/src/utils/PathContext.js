import { createContext } from "react";

const PathContext = createContext();

export default PathContext;